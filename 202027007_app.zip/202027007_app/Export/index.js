const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const port = 8080;

function readUserData() {
  try {
    const data = fs.readFileSync('userdata.json');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading userdata.json:', error.message);
    return [];
  }
}

function writeUserData(userData) {
  try {
    fs.writeFileSync('userdata.json', JSON.stringify(userData, null, 2));
  } catch (error) {
    console.error('Error writing to userdata.json:', error.message);
  }
}

function start_server() {
  console.log('Server Listening...');
}

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/login', function (req, res) {
  const username = req.body.username;
  const password = req.body.password;

  const users = readUserData();

  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    res.send(`환영합니다, ${user.name}님!`);
  } else {
    res.status(400).send('아이디 또는 비밀번호가 올바르지 않습니다.');
  }
});
app.post('/register', function (req, res) {
  const name = req.body.name;
  const username = req.body.username;
  const password = req.body.password;
  const email = req.body.email;

  const users = readUserData();

  const isUsernameTaken = users.some(user => user.username === username);
  const isEmailTaken = users.some(user => user.email === email);

  if (isUsernameTaken || isEmailTaken) {
    res.status(400).send('아이디 또는 이메일이 이미 사용 중입니다.');
  } else {
    const newUser = { name, username, password, email };
    users.push(newUser);
    writeUserData(users);

    res.send('회원가입이 완료되었습니다.');
  }
});
app.post('/find-username', (req, res) => {
  const { email } = req.body;
  fs.readFile('userdata.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading userdata.json:', err);
      return res.status(500).send('Internal Server Error');
    } try {
      const userData = JSON.parse(data);
      const user = userData.find(user => user.email === email);

      if (user) {
        res.send(user.username);
      } else {
        res.status(404).send('User not found');
      }
    } catch (parseError) {
      console.error('Error parsing userdata.json:', parseError);
      res.status(500).send('Internal Server Error');
    }
  });
});

app.post('/find-password', (req, res) => {
  const { username } = req.body;
  fs.readFile('userdata.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading userdata.json:', err);
      return res.status(500).send('Internal Server Error');
    } try {
      const userData = JSON.parse(data);
      const user = userData.find(user => user.username === username);

      if (user) {
        res.send(user.password);
      } else {
        res.status(404).send('User not found');
      }
    } catch (parseError) {
      console.error('Error parsing userdata.json:', parseError);
      res.status(500).send('Internal Server Error');
    }
  });
});
app.post('/update-password', (req, res) => {
  const { username, password } = req.body;
  const users = readUserData();
  const userIndex = users.findIndex(user => user.username === username);

  if (userIndex !== -1) {
    users[userIndex].password = password;
    writeUserData(users);
    res.send('비밀번호가 성공적으로 변경되었습니다.');
  } else {
    res.status(404).send('사용자를 찾을 수 없습니다.');
  }
});

app.get('/:htmlFileName', function (req, res) {
  const htmlFileName = req.params.htmlFileName;
  res.sendFile(path.join(__dirname, htmlFileName));
});

app.use('/assets', express.static(path.join(__dirname, 'assets')));

app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, '-rru.html'));
});

app.listen(port, start_server);
